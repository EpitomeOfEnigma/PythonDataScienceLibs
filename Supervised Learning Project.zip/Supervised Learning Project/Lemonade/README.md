Lemonade Dataset Exercise from "A Gentle Introduction to Pandas" 

https://medium.com/@wbusaka/a-gentle-introduction-to-pandas-5ed17421a59d

